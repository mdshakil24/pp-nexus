
const Singlecommunity = () => {
    return (
        <div>
            
        </div>
    );
};

export default Singlecommunity;